from brain_games.games.brain_even import run


def main():
    run()


if __name__ == '__main__':
    main()
