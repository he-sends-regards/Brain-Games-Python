from brain_games.games.cli import run


def main():
    run()


if __name__ == '__main__':
    main()
