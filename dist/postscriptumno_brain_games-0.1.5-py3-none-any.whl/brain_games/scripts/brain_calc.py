from brain_games.games.brain_calc import run


def main():
    run()


if __name__ == 'main':
    main()
